from gym.envs.registration import register

register(
    id='baseline_env-v0',
    entry_point='baseline_env.envs:baselineEnv',
    max_episode_steps=50,
)

register(
    id='baseline_env-v1',
    entry_point='baseline_env.envs:baselineEnv',
    max_episode_steps=100,
)
