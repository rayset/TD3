from setuptools import setup

setup(name='baseline_env',
      version='0.0.1',
      install_requires=['gym']#And any other dependencies required
)
