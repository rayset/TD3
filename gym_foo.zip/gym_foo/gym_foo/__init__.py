from gym.envs.registration import register

register(
    id='foo-v0',
    entry_point='gym_foo.envs:FooEnv',
    max_episode_steps=50,
)

register(
    id='foo-v1',
    entry_point='gym_foo.envs:FooEnv',
    max_episode_steps=100,
)
