import gym
import math
from gym import spaces
from gym.utils import seeding
import numpy as np


class FooEnv(gym.Env):
    metadata = {
        'render.modes': ['human', 'rgb_array'],
        'video.frames_per_second': 50
    }

    def __init__(self):

        self.tau = 0.02  # seconds between state updates
        self.min_action = 0
        self.max_action = 1.0
        self.n_comm= #number of commodities
        self.n_prov= #number of providers (paths)
        self.num_e= #number of edged
        self.E= #V*E matrix
        # Angle limit set to 2 * theta_threshold_radians so failing observation
        # is still within bounds

        self.seed()
        self.viewer = None
        self.state = None

        self.steps_beyond_done = None

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]


    def compute_latencies(x_p):
        #compute x_e (load on edges)
        x_e=np.zeros((self.num_e,1))
        l_e=np.zeros((self.num_e,1))

        for e in range(self.num_e):
            for p in range(self.n_prov):
                x_e[e,1]=x_e[e,1]+self.E[e,p]*x_p[p,1]
            l_e[e,1]=

        l_p=np.zeros((self.n_prov,1))

        for p in range(self.n_prov):
            for e in range(self.num_e):
                l_p[p,1]=l_p[p,1]+self.E[e,p]*l_e[e,1]

        return(l_p)

    def step(self, action):

        z = self.state
        x_i_p=np.zeros((self.n_comm,self.n_prov))
        x_p=np.zeros((self.n_prov,1))


        #estrai variabili di x
        x_i_p=z[i,p]

        for p in range(self.n_prov):
            for i in range(self.n_comm):
                x_p[p,1]=x_p[p,1]+x_i_p[i,p]

        #calcola migration rates
        r_i_p_q=np.zeros((self.n_comm,self.n_prov,self.n_prov))

        for i in range(self.n_comm):
            for p in range(self.n_prov):
                for q in range(self.n_prov):
                    r_i_p_q[i,p,q]=action[i,p,q]*x_i_p[i,p]

        #calcola latencies
        l_p=compute_latencies(x_p)

        #calcola costi
        c_i=np.zeros((n_comm,1))
        for i in range(self.n_comm):
            for p in range(self.n_prov):
                c_i[i,1]=c_i[i,1]+l_p[p]*x_i_p[i,p]

        #aggiorna stati
        x_i_p_1=np.zeros((self.n_comm,self.n_prov))

        for i in range(self.n_comm):
            inner_sum=0
            for p in range(self.n_prov):
                for q in range(self.n_prov):
                    inner_sum=inner_sum+r_i_p_q[i,q,p]-r_i_p_q[i,p,q]
                x_i_p_1=x_i_p[i,p]+self.tau*inner_sum

        self.state=x_i_p_1

        return x_i_p_1, l_p, c_i, {}

    def reset(self):
        self.state = np.zeros((self.n_comm,self.n_prov))
        return np.array(self.state)

    def render(self, mode='human'):
        return self.viewer.render(return_rgb_array=(mode == 'rgb_array'))

    def close(self):
        if self.viewer:
            self.viewer.close()
