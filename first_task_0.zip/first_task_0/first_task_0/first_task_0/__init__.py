from gym.envs.registration import register

register(
    id='ft0-v0',
    entry_point='first_task_0.envs:Firsttask0',
    max_episode_steps=100,
)

register(
    id='ft0-v1',
    entry_point='first_task_0.envs:Firsttask0',
    max_episode_steps=50,
)
