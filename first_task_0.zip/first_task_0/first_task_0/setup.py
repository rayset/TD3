from setuptools import setup

setup(name='first_task_0',
      version='0.0.1',
      install_requires=['gym']#And any other dependencies required
)
